#ifndef IDONTWANNA_H
#define IDONTWANNA_H

const qreal XMAX = 300;
const qreal YMAX = 225;

#endif // IDONTWANNA_H
