#ifndef DEFS_H
#define DEFS_H

const qreal XMAX = 300;
const qreal YMAX = 225;

#endif // DEFS_H
