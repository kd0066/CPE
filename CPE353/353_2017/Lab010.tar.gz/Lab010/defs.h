#ifndef DEFS_H
#define DEFS_H

const qreal XMAX    =   640;
const qreal YMAX    =   480;

#endif // DEFS_H
