#include "player.h"

Player::Player()
{
    //////////////////////////////////////////////////////////////////////
    //Query Database for images

     QSqlQuery query;

     if(!query.exec( "SELECT * FROM player" ))
     {
        qDebug() << "Error getting image from table: " << query.lastError();
     }
     else
     {
        while(query.next())
        {
            QByteArray outByteArray = query.value(1).toByteArray();
            playerPixmap.loadFromData(outByteArray, "PNG");
        }
     }
    //////////////////////////////////////////////////////////////////////

     //set bullet rotation origin
     this->setTransformOriginPoint(40, 40);

     //set pixmap
     this->setPixmap(playerPixmap.scaled(80, 80, Qt::KeepAspectRatio));

     //timer to make move in 1 direction
     QTimer * t = new QTimer();
     connect(t, SIGNAL(timeout()), this, SLOT(move()));
     t->start(16);
}

void Player::move()
{
    //check if colliding with enemy
    QList<QGraphicsItem *> colliding_items = collidingItems();

    for(int i = 0; i < colliding_items.size(); i++)
    {
        if(typeid(*(colliding_items[i])) == typeid(Enemy))
        {
            scene()->removeItem(this);

            endGame();
            delete this;
            return;
        }
    }

    //top border
    if(scenePos().y() > + 80  && current_dir == up)
    {
        setPos(this->pos().x() + dx, this->pos().y() + dy);
    }
    //left border
    else if(scenePos().x() > +80 && current_dir == l)
    {
        setPos(this->pos().x() + dx, this->pos().y() + dy);
    }
    //bottom border
    else if(scenePos().y() < YMAX - 70 && current_dir == down)
    {
        setPos(this->pos().x() + dx, this->pos().y() + dy);
    }
    //right border
    else if(scenePos().x() < XMAX - 70 && current_dir == r)
    {
        setPos(this->pos().x() + dx, this->pos().y() + dy);
    }
}

//set dx, dy, and current direction
void Player::keyPressEvent(QKeyEvent * event)
{
    if(event && event->key() == Qt::Key_Up)
    {
        //up
        dx = 0;
        dy = -3;
        current_dir = up;
        this->setRotation(-90);
    }
    else if (event && event->key() == Qt::Key_Left)
    {
        //left
        dx = -3;
        dy = 0;
        current_dir = l;
        this->setRotation(180);
    }
    else if(event && event->key() == Qt::Key_Down)
    {
        //down
        dx = 0;
        dy= 3;
        current_dir = down;
        this->setRotation(90);
    }
    else if(event && event->key() == Qt::Key_Right)
    {
        //right
        dx = 3;
        dy = 0;
        current_dir = r;
        this->setRotation(0);
    }
    else if(event && event->key() == Qt::Key_Space)
    {
        if(!(current_dir == stop))
        {
            //relative pos of player
            QPointF currentpos = this->pos();

            //create the bullet
            //make bullet appear in middle of player
            //add to scene
            Bullet * bullet = new Bullet(current_dir, currentpos);
            scene()->addItem(bullet);
        }
    }
    else
    {
        //stop
        dx = 0;
        dy = 0;
        current_dir = stop;
    }

}

//modal for end game
void Player::endGame()
{
    QDialog * q = new QDialog();
    QHBoxLayout * l = new QHBoxLayout();
    QLabel * lab = new QLabel();

    q->setLayout(l);
    lab->setText("Game Over");
    l->addWidget(lab);

    q->exec();
}
