#ifndef DEFS_H
#define DEFS_H

const int XMAX = 1024;
const int YMAX = 768;
enum direction {up, down, l, r, stop};

#endif // DEFS_H
