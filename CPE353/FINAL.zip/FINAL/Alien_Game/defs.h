#ifndef DEFS_H
#define DEFS_H

#include <QSqlDatabase>

const int XMAX = 1200;
const int YMAX = 800;

enum direction {up, down, l, r, stop};

#endif // DEFS_H
