#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDialog>
#include <QTextBrowser>
#include <QIntValidator>
#include <QDial>
#include <QtDebug>
#include <QFileDialog>
#include <QMouseEvent>
#include <QEvent>
#include <QRegularExpressionValidator>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

